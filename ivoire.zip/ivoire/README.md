# IVOIRE PROPULSION — Plateforme d'adhésion (V1 Frontend)

V1 **uniquement frontend** de la plateforme d'adhésion au réseau **IVOIRE PROPULSION**.

> « Là où les idées se forment, les connexions se créent et les financements naissent. »

---

## 🎯 Objectif

Permettre à un entrepreneur, porteur de projet, investisseur ou professionnel
de demander son adhésion au réseau via un formulaire multi-étapes moderne,
avec une page de confirmation et un numéro de dossier.

**Aucun backend, aucune base de données, aucune authentification, aucun paiement réel.**

---

## 🛠️ Technologies

- HTML5
- CSS3 (design system custom)
- JavaScript Vanilla (aucun framework)
- Font Awesome 6.5 (CDN) pour toutes les icônes
- Google Fonts : **Inter** + **Playfair Display**

---

## 📁 Structure

```
ivoire-propulsion-members/
│
├── index.html               → Landing page
├── adhesion.html            → Formulaire multi-étapes
├── confirmation.html        → Page de succès + numéro de dossier
├── privacy.html             → Placeholder politique de confidentialité
├── README.md
│
└── assets/
    ├── css/
    │   └── style.css        → Design system complet
    ├── js/
    │   └── script.js        → Menu, animations, formulaire, stockage
    └── images/
        └── logo.png         → Logo (à ajouter)
```

---

## 🚀 Démarrage local

1. Ouvrir le dossier dans **VS Code**
2. Installer l'extension **Live Server**
3. Clic droit sur `index.html` → **Open with Live Server**

> Si aucun `logo.png` n'est présent dans `assets/images/`, un fallback
> Font Awesome (icône éclair) s'affiche automatiquement.

---

## 🎨 Direction artistique

- Fond noir / gris très foncé
- Accent **orange / doré** (`#f5a623`)
- Cartes modernes, bordures discrètes
- Effets lumineux subtils (glow)
- Animations légères au scroll et au survol
- Mobile-first, parfaitement responsive (320px → 1440px+)
- **Aucun emoji** dans l'interface : uniquement Font Awesome

---

## 🧩 Formulaire d'adhésion

5 étapes avec barre de progression :

| # | Étape | Champs principaux |
|---|-------|-------------------|
| 01 | Identité | `full_name`, `whatsapp`, `age`, `residence` |
| 02 | Profil professionnel | `profession`, `activity_sector`, `member_status`, `expertise` |
| 03 | Projets et besoins | `short_term_project`, `long_term_project`, `funding_needs` |
| 04 | Réseau | `partnership_needs` |
| 05 | Validation | Consentement + récapitulatif |

**Validation JS** (aucun `alert`) :
- Erreurs affichées sous les champs
- Champ en erreur mis en évidence
- Scroll automatique vers la première erreur
- Focus sur le champ invalide

---

## 💾 Persistance (temporaire)

Après validation, les données sont enregistrées dans `sessionStorage` :

```js
{
  ...formData,
  file_number: "IP-2026-XXXXXX",
  status: "EN ATTENTE DE PAIEMENT",
  created_at: "2026-01-01T10:00:00.000Z"
}
```

Puis redirection vers `confirmation.html`.

---

## 🔌 Préparation backend (futur)

Le code est **déjà prêt** pour un backend PHP/MySQL.

Dans `assets/js/script.js`, la fonction `submitMembership()` contient
un commentaire indiquant où brancher un `fetch POST` :

```js
async function submitMembership(payload) {
  // ÉTAPE FUTURE (PHP/MySQL) :
  // const res = await fetch('api/adhesion.php', {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify(payload)
  // });
  // return await res.json();

  /* simulation locale actuelle */
}
```

Il suffira de remplacer `sessionStorage` par ce `fetch` sans toucher au reste.

Les champs HTML utilisent déjà les bons attributs `name=""` :

`full_name`, `whatsapp`, `age`, `residence`, `profession`, `activity_sector`,
`short_term_project`, `long_term_project`, `funding_needs`, `expertise`,
`partnership_needs`, `member_status`, `consent`.

---

## 💳 Paiement (placeholder)

Dans `assets/js/script.js` :

```js
const CONFIG = {
  PAYMENT_URL: '#' // ← remplacer plus tard par le vrai lien
};
```

Le bouton **« Payer mon adhésion »** sur `confirmation.html` utilise
directement cette variable. Aucun autre changement à faire.

---

## ✅ Fonctionnalités V1

- [x] Landing page premium responsive
- [x] Menu hamburger mobile
- [x] Animations au scroll (IntersectionObserver)
- [x] Formulaire multi-étapes + barre de progression
- [x] Validation complète côté client
- [x] Récapitulatif à l'étape 5
- [x] Case de consentement obligatoire
- [x] Génération d'un numéro `IP-2026-XXXXXX`
- [x] Page de confirmation professionnelle
- [x] Bouton paiement configurable
- [x] Accessibilité (labels, focus, aria)
- [x] Aucun backend / SQL / PHP

---

## 🔒 Rappel important

- Ne pas utiliser d'emoji dans l'interface → **Font Awesome uniquement**
- IVOIRE PROPULSION **facilite les mises en relation** ; l'adhésion ne
  garantit **pas** un financement automatique
- Le lien « Politique de confidentialité » pointe vers `#` tant que la
  page `privacy.html` n'est pas finalisée

---

## 📌 Prochaines étapes (V2+)

- [ ] Backend PHP + MySQL (endpoint `api/adhesion.php`)
- [ ] Authentification membre
- [ ] Espace membre
- [ ] Intégration paiement réel (Mobile Money / CinetPay / Stripe)
- [ ] Tableau de bord admin
- [ ] Politique de confidentialité complète

---

© IVOIRE PROPULSION — Tous droits réservés.