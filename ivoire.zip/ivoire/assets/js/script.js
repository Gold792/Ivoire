/* =========================================================
   IVOIRE PROPULSION — Script V1 (frontend uniquement)
   ---------------------------------------------------------
   NOTE : ce fichier prépare déjà l'intégration future d'un
   backend PHP/MySQL via la fonction `submitMembership()`.
   Il suffira de remplacer l'appel à sessionStorage par un
   fetch POST vers un endpoint PHP.
   ========================================================= */

(function () {
  'use strict';

  /* ---------- Configuration globale ---------- */
  const CONFIG = {
    // À remplacer plus tard par la vraie URL de paiement.
    PAYMENT_URL: '#',
    // Clé sessionStorage pour la demande d'adhésion.
    STORAGE_KEY: 'ivoire_propulsion_membership',
    // Préfixe du numéro de dossier.
    FILE_PREFIX: 'IP-2026-',
    // Nombre de chiffres aléatoires du dossier.
    FILE_DIGITS: 6
  };

  /* =========================================================
     Utilitaires
     ========================================================= */
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

  const onReady = (fn) => {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  };

  /* =========================================================
     1. Header : scroll + menu mobile
     ========================================================= */
  function initHeader() {
    const header = $('#siteHeader');
    const toggle = $('#navToggle');
    const nav = $('#mainNav');

    if (header) {
      const onScroll = () => {
        header.classList.toggle('is-scrolled', window.scrollY > 12);
      };
      window.addEventListener('scroll', onScroll, { passive: true });
      onScroll();
    }

    if (toggle && nav) {
      toggle.addEventListener('click', () => {
        const open = nav.classList.toggle('is-open');
        toggle.classList.toggle('is-open', open);
        toggle.setAttribute('aria-expanded', String(open));
      });

      // Fermer au clic sur un lien (mobile)
      $$('a', nav).forEach((link) => {
        link.addEventListener('click', () => {
          nav.classList.remove('is-open');
          toggle.classList.remove('is-open');
          toggle.setAttribute('aria-expanded', 'false');
        });
      });
    }
  }

  /* =========================================================
     2. Année dynamique dans le footer
     ========================================================= */
  function initFooterYear() {
    $$('#year').forEach((el) => {
      el.textContent = new Date().getFullYear();
    });
  }

  /* =========================================================
     3. Animations au scroll
     ========================================================= */
  function initReveal() {
    const items = $$('.reveal');
    if (!items.length) return;

    if (!('IntersectionObserver' in window)) {
      items.forEach((el) => el.classList.add('is-visible'));
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, i) => {
          if (entry.isIntersecting) {
            setTimeout(() => entry.target.classList.add('is-visible'), i * 60);
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );

    items.forEach((el) => io.observe(el));
  }

  /* =========================================================
     4. Génération d'un numéro de dossier
     ========================================================= */
  function generateFileNumber() {
    let digits = '';
    for (let i = 0; i < CONFIG.FILE_DIGITS; i++) {
      digits += Math.floor(Math.random() * 10);
    }
    return CONFIG.FILE_PREFIX + digits;
  }

  /* =========================================================
     5. Persistance (sessionStorage pour l'instant)
     ---------------------------------------------------------
     ⚠️ Plus tard : remplacer par un fetch POST vers PHP.
     ========================================================= */
  function saveMembership(data) {
    try {
      sessionStorage.setItem(CONFIG.STORAGE_KEY, JSON.stringify(data));
      return true;
    } catch (err) {
      console.error('[IVOIRE PROPULSION] Erreur sessionStorage :', err);
      return false;
    }
  }

  function loadMembership() {
    try {
      const raw = sessionStorage.getItem(CONFIG.STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (err) {
      console.error('[IVOIRE PROPULSION] Erreur lecture sessionStorage :', err);
      return null;
    }
  }

  /* =========================================================
     6. Soumission future (préparée pour PHP/MySQL)
     ========================================================= */
  async function submitMembership(payload) {
    /*
      ÉTAPE FUTURE (PHP/MySQL) :
      ---------------------------------------------
      const res = await fetch('api/adhesion.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      return await res.json();
      ---------------------------------------------
      Pour l'instant : simulation locale.
    */
    const record = {
      ...payload,
      file_number: generateFileNumber(),
      status: 'EN ATTENTE DE PAIEMENT',
      created_at: new Date().toISOString()
    };

    saveMembership(record);
    return record;
  }

  /* =========================================================
     7. Validation des champs
     ========================================================= */
  const validators = {
    full_name(v) {
      v = (v || '').trim();
      if (!v) return 'Veuillez saisir votre nom et prénom(s).';
      if (v.length < 3) return 'Le nom doit contenir au moins 3 caractères.';
      if (!/^[a-zA-ZÀ-ÿ' \-.]+$/.test(v)) return 'Le nom contient des caractères non valides.';
      return null;
    },
    whatsapp(v) {
      v = (v || '').trim();
      if (!v) return 'Veuillez saisir votre numéro WhatsApp.';
      const digits = v.replace(/\D/g, '');
      if (digits.length < 8) return 'Le numéro WhatsApp semble trop court.';
      if (digits.length > 15) return 'Le numéro WhatsApp semble trop long.';
      return null;
    },
    age(v) {
      v = (v || '').toString().trim();
      if (!v) return "Veuillez indiquer votre âge.";
      const n = Number(v);
      if (Number.isNaN(n)) return "L'âge doit être un nombre.";
      if (n < 16) return "Vous devez avoir au moins 16 ans.";
      if (n > 100) return "L'âge indiqué n'est pas valide.";
      return null;
    },
    residence(v) {
      v = (v || '').trim();
      if (!v) return "Veuillez indiquer votre lieu d'habitation.";
      if (v.length < 2) return 'Lieu invalide.';
      return null;
    },
    profession(v) {
      v = (v || '').trim();
      if (!v) return 'Veuillez indiquer votre profession / fonction.';
      return null;
    },
    activity_sector(v) {
      v = (v || '').trim();
      if (!v) return "Veuillez indiquer votre secteur d'activité.";
      return null;
    },
    short_term_project(v) {
      v = (v || '').trim();
      if (!v) return 'Veuillez décrire votre projet à court terme.';
      if (v.length < 20) return 'Décrivez ce projet en au moins 20 caractères.';
      return null;
    },
    long_term_project(v) {
      v = (v || '').trim();
      if (!v) return 'Veuillez décrire votre projet à long terme.';
      if (v.length < 20) return 'Décrivez ce projet en au moins 20 caractères.';
      return null;
    },
    funding_needs(v) {
      v = (v || '').trim();
      if (!v) return 'Veuillez préciser vos besoins de financement.';
      if (v.length < 15) return 'Précisez davantage vos besoins (min. 15 caractères).';
      return null;
    },
    expertise(v) {
      v = (v || '').trim();
      if (!v) return 'Veuillez décrire vos compétences / expertises.';
      if (v.length < 10) return 'Décrivez vos compétences en au moins 10 caractères.';
      return null;
    },
    partnership_needs(v) {
      v = (v || '').trim();
      if (!v) return 'Veuillez préciser le partenariat recherché.';
      if (v.length < 15) return 'Précisez davantage votre recherche (min. 15 caractères).';
      return null;
    },
    member_status(v) {
      v = (v || '').trim();
      if (!v) return 'Veuillez sélectionner votre statut.';
      return null;
    },
    consent(v) {
      if (!v) return 'Vous devez accepter les conditions pour continuer.';
      return null;
    }
  };

  function validateField(field) {
    const name = field.name;
    if (!validators[name]) return true;

    let value;
    if (field.type === 'checkbox') value = field.checked ? '1' : '';
    else value = field.value;

    const error = validators[name](value);
    const wrapper = field.closest('.field');
    const errorEl = document.querySelector(`[data-error-for="${name}"]`);

    if (error) {
      if (wrapper) wrapper.classList.add('has-error');
      if (errorEl) {
        errorEl.textContent = error;
        errorEl.classList.add('is-visible');
      }
      return false;
    } else {
      if (wrapper) wrapper.classList.remove('has-error');
      if (errorEl) {
        errorEl.textContent = '';
        errorEl.classList.remove('is-visible');
      }
      return true;
    }
  }

  /* =========================================================
     8. Formulaire multi-étapes
     ========================================================= */
  function initForm() {
    const form = $('#adhesionForm');
    if (!form) return;

    const steps = $$('.form-step', form);
    const progressFill = $('#progressFill');
    const progressSteps = $$('.progress-step');
    const totalSteps = steps.length;
    let currentStep = 1;

    /* -- Met à jour la barre de progression + affichage étape -- */
    function goToStep(step, { scroll = true } = {}) {
      currentStep = Math.max(1, Math.min(step, totalSteps));

      steps.forEach((s) => {
        s.classList.toggle('is-active', Number(s.dataset.step) === currentStep);
      });

      progressSteps.forEach((el) => {
        const n = Number(el.dataset.stepLabel);
        el.classList.toggle('is-active', n === currentStep);
        el.classList.toggle('is-done', n < currentStep);
      });

      if (progressFill) {
        progressFill.style.width = `${(currentStep / totalSteps) * 100}%`;
      }

      if (currentStep === totalSteps) buildReview();

      if (scroll) {
        const y = form.getBoundingClientRect().top + window.scrollY - 110;
        window.scrollTo({ top: y, behavior: 'smooth' });
      }
    }

    /* -- Valide tous les champs d'une étape -- */
    function validateStep(step) {
      const stepEl = steps.find((s) => Number(s.dataset.step) === step);
      if (!stepEl) return true;

      const fields = $$('input, select, textarea', stepEl);
      let firstInvalid = null;
      let valid = true;

      fields.forEach((field) => {
        if (!validators[field.name]) return;
        const ok = validateField(field);
        if (!ok) {
          valid = false;
          if (!firstInvalid) firstInvalid = field;
        }
      });

      if (!valid && firstInvalid) {
        const wrapper = firstInvalid.closest('.field');
        const y = (wrapper || firstInvalid).getBoundingClientRect().top + window.scrollY - 130;
        window.scrollTo({ top: y, behavior: 'smooth' });
        setTimeout(() => firstInvalid.focus({ preventScroll: true }), 350);
      }

      return valid;
    }

    /* -- Boutons suivants -- */
    $$('[data-next]', form).forEach((btn) => {
      btn.addEventListener('click', () => {
        if (validateStep(currentStep)) goToStep(currentStep + 1);
      });
    });

    /* -- Boutons précédents -- */
    $$('[data-prev]', form).forEach((btn) => {
      btn.addEventListener('click', () => goToStep(currentStep - 1));
    });

    /* -- Validation live après interaction -- */
    $$('input, select, textarea', form).forEach((field) => {
      const evt = field.type === 'checkbox' || field.tagName === 'SELECT' ? 'change' : 'blur';
      field.addEventListener(evt, () => {
        if (field.closest('.form-step')?.classList.contains('is-active')) {
          validateField(field);
        }
      });
      field.addEventListener('input', () => {
        const wrapper = field.closest('.field');
        if (wrapper && wrapper.classList.contains('has-error')) validateField(field);
      });
    });

    /* -- Récapitulatif (étape 5) -- */
    function buildReview() {
      const reviewList = $('#reviewList');
      if (!reviewList) return;
      const data = collectFormData();

      const summary = [
        { label: 'Identité', value: data.full_name },
        { label: 'Profil', value: data.member_status + (data.profession ? ' — ' + data.profession : '') },
        { label: 'Projet court terme', value: truncate(data.short_term_project, 40) },
        { label: 'Besoins', value: truncate(data.funding_needs, 40) }
      ];

      reviewList.innerHTML = summary
        .map(
          (row) =>
            `<li><span>${escapeHTML(row.label)}</span><em>${escapeHTML(row.value || '—')}</em></li>`
        )
        .join('');
    }

    function truncate(str, n) {
      str = (str || '').trim();
      if (!str) return '—';
      return str.length > n ? str.slice(0, n - 1) + '…' : str;
    }

    /* -- Collecte des données du formulaire -- */
    function collectFormData() {
      const data = {};
      $$('input, select, textarea', form).forEach((field) => {
        if (!field.name) return;
        if (field.type === 'checkbox') data[field.name] = field.checked;
        else data[field.name] = field.value.trim();
      });
      return data;
    }

    /* -- Soumission -- */
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      // Valider toutes les étapes une par une
      for (let s = 1; s <= totalSteps; s++) {
        if (!validateStep(s)) {
          goToStep(s);
          return;
        }
      }

      const submitBtn = $('button[type="submit"]', form);
      const originalHTML = submitBtn ? submitBtn.innerHTML : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Enregistrement...';
      }

      try {
        const payload = collectFormData();
        const record = await submitMembership(payload);

        // Petite latence simulée pour UX
        await new Promise((r) => setTimeout(r, 700));

        // Redirection
        window.location.href = 'confirmation.html';
      } catch (err) {
        console.error('[IVOIRE PROPULSION] Erreur soumission :', err);
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalHTML;
        }
      }
    });

    /* -- Init -- */
    goToStep(1, { scroll: false });
  }

  /* =========================================================
     9. Page de confirmation
     ========================================================= */
  function initConfirmation() {
    const fileEl = $('#fileNumber');
    const payBtn = $('#payBtn');
    if (!fileEl && !payBtn) return;

    const record = loadMembership();

    // Numéro de dossier
    if (fileEl) {
      if (record && record.file_number) {
        fileEl.textContent = record.file_number;
      } else {
        fileEl.textContent = 'IP-2026-XXXXXX';
      }
    }

    // Bouton paiement
    if (payBtn) {
      payBtn.setAttribute('href', CONFIG.PAYMENT_URL);
      if (CONFIG.PAYMENT_URL === '#') {
        payBtn.addEventListener('click', (e) => {
          e.preventDefault();
          // Placeholder tant que l'URL de paiement n'est pas branchée.
          console.info(
            '[IVOIRE PROPULSION] URL de paiement non configurée. Modifiez CONFIG.PAYMENT_URL dans assets/js/script.js.'
          );
        });
      }
    }
  }

  /* =========================================================
     10. Sécurité simple : échappement HTML
     ========================================================= */
  function escapeHTML(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  /* =========================================================
     Bootstrap
     ========================================================= */
  onReady(() => {
    initHeader();
    initFooterYear();
    initReveal();
    initForm();
    initConfirmation();
  });
})();